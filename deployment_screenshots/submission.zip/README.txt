Git Repo: https://github.com/Akeme26/imageFilter.git

Endpoint Link: http://imagefilterapp-env.eba-ingpxfud.us-east-1.elasticbeanstalk.com/